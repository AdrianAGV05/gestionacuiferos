package com.iitca.tecnodesarrollo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.iitca.tecnodesarrollo.dto.Acuifero;

public interface AcuiferoRepo extends JpaRepository<Acuifero, Integer> {

}