package com.iitca.tecnodesarrollo.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "acuifero")
public class Acuifero {

	@Id
	private Integer Acu_clave;
	@Column(name="acu_nombre")
	private String Acu_nombre;
	@Column(columnDefinition="TEXT")
	private String Acu_descripcion;
	//private Blob Acu_limites;
	@Column(name="acu_num_op")
	private Integer Acu_num_op;
	
	
	
}