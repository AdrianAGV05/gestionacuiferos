package com.iitca.tecnodesarrollo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XibalbaDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
